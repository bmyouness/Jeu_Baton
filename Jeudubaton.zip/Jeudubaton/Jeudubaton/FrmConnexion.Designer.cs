﻿namespace Jeudubaton
{
    partial class FrmConnexion
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TxtBoxIdentifiant = new TextBox();
            TxtBoxMotdepasse = new TextBox();
            BtnConnexion = new Button();
            label1 = new Label();
            label2 = new Label();
            BtnRedirectionIdentifier = new Button();
            label3 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // TxtBoxIdentifiant
            // 
            TxtBoxIdentifiant.Location = new Point(312, 114);
            TxtBoxIdentifiant.Name = "TxtBoxIdentifiant";
            TxtBoxIdentifiant.Size = new Size(125, 27);
            TxtBoxIdentifiant.TabIndex = 0;
            // 
            // TxtBoxMotdepasse
            // 
            TxtBoxMotdepasse.Location = new Point(312, 181);
            TxtBoxMotdepasse.Name = "TxtBoxMotdepasse";
            TxtBoxMotdepasse.Size = new Size(125, 27);
            TxtBoxMotdepasse.TabIndex = 1;
            // 
            // BtnConnexion
            // 
            BtnConnexion.Location = new Point(274, 256);
            BtnConnexion.Name = "BtnConnexion";
            BtnConnexion.Size = new Size(197, 29);
            BtnConnexion.TabIndex = 2;
            BtnConnexion.Text = "Connexion";
            BtnConnexion.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(226, 117);
            label1.Name = "label1";
            label1.Size = new Size(80, 20);
            label1.TabIndex = 3;
            label1.Text = "Identifiant:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(205, 183);
            label2.Name = "label2";
            label2.Size = new Size(101, 20);
            label2.TabIndex = 4;
            label2.Text = "Mot de passe:";
            // 
            // BtnRedirectionIdentifier
            // 
            BtnRedirectionIdentifier.Location = new Point(247, 327);
            BtnRedirectionIdentifier.Name = "BtnRedirectionIdentifier";
            BtnRedirectionIdentifier.Size = new Size(94, 29);
            BtnRedirectionIdentifier.TabIndex = 5;
            BtnRedirectionIdentifier.Text = "S'identifier";
            BtnRedirectionIdentifier.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(128, 327);
            label3.Name = "label3";
            label3.Size = new Size(113, 20);
            label3.TabIndex = 6;
            label3.Text = "Pas de compte?";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label4.ForeColor = Color.CornflowerBlue;
            label4.Location = new Point(300, 30);
            label4.Name = "label4";
            label4.Size = new Size(171, 35);
            label4.TabIndex = 7;
            label4.Text = "Se Connecter";
            // 
            // FrmConnexion
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(BtnRedirectionIdentifier);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(BtnConnexion);
            Controls.Add(TxtBoxMotdepasse);
            Controls.Add(TxtBoxIdentifiant);
            Name = "FrmConnexion";
            Text = "FrmConnexion";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox TxtBoxIdentifiant;
        private TextBox TxtBoxMotdepasse;
        private Button BtnConnexion;
        private Label label1;
        private Label label2;
        private Button BtnRedirectionIdentifier;
        private Label label3;
        private Label label4;
    }
}
