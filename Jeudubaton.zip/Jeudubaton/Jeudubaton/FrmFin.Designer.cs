﻿namespace Jeudubaton
{
    partial class FrmFin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnNouvPartie = new Button();
            BtnRevenche = new Button();
            LabelJoueurGagnant = new Label();
            SuspendLayout();
            // 
            // BtnNouvPartie
            // 
            BtnNouvPartie.Location = new Point(195, 287);
            BtnNouvPartie.Name = "BtnNouvPartie";
            BtnNouvPartie.Size = new Size(161, 29);
            BtnNouvPartie.TabIndex = 0;
            BtnNouvPartie.Text = "Nouvelle Partie";
            BtnNouvPartie.UseVisualStyleBackColor = true;
            // 
            // BtnRevenche
            // 
            BtnRevenche.Location = new Point(400, 287);
            BtnRevenche.Name = "BtnRevenche";
            BtnRevenche.Size = new Size(118, 29);
            BtnRevenche.TabIndex = 1;
            BtnRevenche.Text = "Revanche";
            BtnRevenche.UseVisualStyleBackColor = true;
            // 
            // LabelJoueurGagnant
            // 
            LabelJoueurGagnant.AutoSize = true;
            LabelJoueurGagnant.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            LabelJoueurGagnant.ForeColor = Color.CornflowerBlue;
            LabelJoueurGagnant.Location = new Point(260, 52);
            LabelJoueurGagnant.Name = "LabelJoueurGagnant";
            LabelJoueurGagnant.Size = new Size(207, 35);
            LabelJoueurGagnant.TabIndex = 2;
            LabelJoueurGagnant.Text = "La partie est fini";
            // 
            // FrmFin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(LabelJoueurGagnant);
            Controls.Add(BtnRevenche);
            Controls.Add(BtnNouvPartie);
            Name = "FrmFin";
            Text = "FrmFin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnNouvPartie;
        private Button BtnRevenche;
        private Label LabelJoueurGagnant;
    }
}