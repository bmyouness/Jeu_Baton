﻿namespace Jeudubaton
{
    partial class FrmInscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnInscrire = new Button();
            label3 = new Label();
            label4 = new Label();
            TxtBoxIdentifiant = new TextBox();
            TxtBoxMdp = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // BtnInscrire
            // 
            BtnInscrire.Location = new Point(283, 277);
            BtnInscrire.Name = "BtnInscrire";
            BtnInscrire.Size = new Size(144, 29);
            BtnInscrire.TabIndex = 0;
            BtnInscrire.Text = "S'inscrire";
            BtnInscrire.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(150, 155);
            label3.Name = "label3";
            label3.Size = new Size(80, 20);
            label3.TabIndex = 3;
            label3.Text = "Identifiant:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(150, 201);
            label4.Name = "label4";
            label4.Size = new Size(101, 20);
            label4.TabIndex = 4;
            label4.Text = "Mot de passe:";
            // 
            // TxtBoxIdentifiant
            // 
            TxtBoxIdentifiant.Location = new Point(264, 152);
            TxtBoxIdentifiant.Name = "TxtBoxIdentifiant";
            TxtBoxIdentifiant.Size = new Size(186, 27);
            TxtBoxIdentifiant.TabIndex = 5;
            // 
            // TxtBoxMdp
            // 
            TxtBoxMdp.Location = new Point(264, 198);
            TxtBoxMdp.Name = "TxtBoxMdp";
            TxtBoxMdp.Size = new Size(186, 27);
            TxtBoxMdp.TabIndex = 8;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label1.ForeColor = Color.CornflowerBlue;
            label1.Location = new Point(286, 37);
            label1.Name = "label1";
            label1.Size = new Size(141, 35);
            label1.TabIndex = 9;
            label1.Text = "Inscription";
            // 
            // FrmInscription
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(TxtBoxMdp);
            Controls.Add(TxtBoxIdentifiant);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(BtnInscrire);
            Name = "FrmInscription";
            Text = "FrmInscription";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnInscrire;
        private Label label3;
        private Label label4;
        private TextBox TxtBoxIdentifiant;
        private TextBox TxtBoxMdp;
        private Label label1;
    }
}