﻿namespace Jeudubaton
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            labelJoueurCommence = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            TxtBoxNbBatonaEnlever = new TextBox();
            listBoxNbBatonRestant = new ListBox();
            BtnValider = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // labelJoueurCommence
            // 
            labelJoueurCommence.AutoSize = true;
            labelJoueurCommence.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelJoueurCommence.Location = new Point(22, 78);
            labelJoueurCommence.Name = "labelJoueurCommence";
            labelJoueurCommence.Size = new Size(150, 20);
            labelJoueurCommence.TabIndex = 3;
            labelJoueurCommence.Text = "Joueur 1 commence";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label2.ForeColor = SystemColors.MenuHighlight;
            label2.Location = new Point(297, 27);
            label2.Name = "label2";
            label2.Size = new Size(168, 35);
            label2.TabIndex = 4;
            label2.Text = "Jeu du Bâton";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(22, 191);
            label3.Name = "label3";
            label3.Size = new Size(251, 20);
            label3.TabIndex = 6;
            label3.Text = "Entrée le nombre de bâton a enlever";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(22, 129);
            label4.Name = "label4";
            label4.Size = new Size(104, 20);
            label4.TabIndex = 7;
            label4.Text = "Baton Restant:";
            // 
            // TxtBoxNbBatonaEnlever
            // 
            TxtBoxNbBatonaEnlever.Location = new Point(283, 188);
            TxtBoxNbBatonaEnlever.Name = "TxtBoxNbBatonaEnlever";
            TxtBoxNbBatonaEnlever.Size = new Size(61, 27);
            TxtBoxNbBatonaEnlever.TabIndex = 8;
            // 
            // listBoxNbBatonRestant
            // 
            listBoxNbBatonRestant.FormattingEnabled = true;
            listBoxNbBatonRestant.Location = new Point(132, 129);
            listBoxNbBatonRestant.Name = "listBoxNbBatonRestant";
            listBoxNbBatonRestant.Size = new Size(160, 24);
            listBoxNbBatonRestant.TabIndex = 9;
            // 
            // BtnValider
            // 
            BtnValider.Location = new Point(297, 246);
            BtnValider.Name = "BtnValider";
            BtnValider.Size = new Size(94, 29);
            BtnValider.TabIndex = 10;
            BtnValider.Text = "Valider";
            BtnValider.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BtnValider);
            Controls.Add(listBoxNbBatonRestant);
            Controls.Add(TxtBoxNbBatonaEnlever);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(labelJoueurCommence);
            Name = "Form1";
            Text = "FrmJeu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelJoueurCommence;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox TxtBoxNbBatonaEnlever;
        private ListBox listBoxNbBatonRestant;
        private Button BtnValider;
        private System.Windows.Forms.Timer timer1;
    }
}