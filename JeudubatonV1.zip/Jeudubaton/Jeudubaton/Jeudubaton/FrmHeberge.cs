﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Jeudubaton.Models;

namespace Jeudubaton
{
    public partial class FrmHeberge : Form
    {
        public static int IdPartieCourante
        {
            get;
            private set;
        }

        public FrmHeberge()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Créer un code pour rejoindre la partie, le mettre dans la bdd et aller sur la page FrmPartie
            const string alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
            var rnd = new Random();
            string code = "";

            using (FortBoyardYounessMaximePContext bdd = new FortBoyardYounessMaximePContext())
            {
                bool codeUnique = false;

                while (!codeUnique)
                {
                    // Générer un code de 6 caractères
                    code = new string(Enumerable.Range(0, 6)
                        .Select(_ => alphabet[rnd.Next(alphabet.Length)])
                        .ToArray());

                    // Vérifier si le code existe déjà dans la base
                    codeUnique = !bdd.Parties.Any(p => p.CodePartie == code);
                }

                // Créer la nouvelle partie avec SEULEMENT le code (pas d'autres champs obligatoires)
                Partie new_code = new Partie();
                new_code.CodePartie = code;

                new_code.IdCompte1 = FrmConnexion.IdCompteCourant;
                
                // Ajouter à la base de données
                bdd.Parties.Add(new_code);
                bdd.SaveChanges();

                IdPartieCourante = new_code.Id;
            }



            FrmPartie new_partie = new FrmPartie();
            new_partie.Show();
        }
    }
}
