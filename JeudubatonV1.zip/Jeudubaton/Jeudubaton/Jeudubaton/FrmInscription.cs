﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Jeudubaton.Models;

namespace Jeudubaton
{
    public partial class FrmInscription : Form
    {
        public FrmInscription()
        {
            InitializeComponent();
        }

        private void TxtBoxIdentifiant_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtBoxMdp_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnInscrire_Click(object sender, EventArgs e)
        {
            using (FortBoyardYounessMaximePContext bdd = new FortBoyardYounessMaximePContext())
            {
                Compte new_user = new Compte();

                new_user.Mail = TxtBoxIdentifiant.Text;
                new_user.Password= TxtBoxMdp.Text;
                new_user.PartiePerdu = 0;
                new_user.PartieGagné = 0;
                bdd.Comptes.Add(new_user);
                bdd.SaveChanges();

                MessageBox.Show("Inscription réussi");
            }
        }
    }
}
