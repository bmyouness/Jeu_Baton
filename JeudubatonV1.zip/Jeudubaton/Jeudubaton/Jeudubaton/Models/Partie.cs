﻿using System;
using System.Collections.Generic;

namespace Jeudubaton.Models;

public partial class Partie
{
    public int Id { get; set; }

    public int? Gagnant { get; set; }

    public int? Perdant { get; set; }

    public int? NbrBatonnets { get; set; }

    public int TourJouer { get; set; }

    public string? CodePartie { get; set; }

    public int? IdCompte2 { get; set; }

    public int? IdCompte1 { get; set; }

    public virtual Compte? IdCompte1Navigation { get; set; }

    public virtual Compte? IdCompte2Navigation { get; set; }

    public virtual ICollection<Tour> Tours { get; set; } = new List<Tour>();
}
