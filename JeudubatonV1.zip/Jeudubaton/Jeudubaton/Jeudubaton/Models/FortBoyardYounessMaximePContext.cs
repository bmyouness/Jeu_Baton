﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Jeudubaton.Models;

public partial class FortBoyardYounessMaximePContext : DbContext
{
    public FortBoyardYounessMaximePContext()
    {
    }

    public FortBoyardYounessMaximePContext(DbContextOptions<FortBoyardYounessMaximePContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Compte> Comptes { get; set; }

    public virtual DbSet<Partie> Parties { get; set; }

    public virtual DbSet<Tour> Tours { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=2a03:5840:111:1024:508f:fc67:4795:f4d3;Database=FortBoyardYounessMaximeP;User ID=sa;Password=erty64%;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Compte>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Compte__3213E83F34417380");

            entity.ToTable("Compte");

            entity.HasIndex(e => e.Password, "UQ__Compte__6E2DBEDE5D9BE369").IsUnique();

            entity.HasIndex(e => e.Mail, "UQ__Compte__7A2129046C91F69C").IsUnique();

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Mail)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("mail");
            entity.Property(e => e.PartieGagné).HasColumnName("partie_gagné");
            entity.Property(e => e.PartiePerdu).HasColumnName("partie_perdu");
            entity.Property(e => e.Password)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("password");
        });

        modelBuilder.Entity<Partie>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Partie__3213E83F8FDA97D1");

            entity.ToTable("Partie");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CodePartie)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("code_partie");
            entity.Property(e => e.Gagnant).HasColumnName("gagnant");
            entity.Property(e => e.IdCompte1).HasColumnName("id_compte_1");
            entity.Property(e => e.IdCompte2).HasColumnName("id_compte_2");
            entity.Property(e => e.NbrBatonnets).HasColumnName("nbr_batonnets");
            entity.Property(e => e.Perdant).HasColumnName("perdant");
            entity.Property(e => e.TourJouer).HasColumnName("tour_jouer");

            entity.HasOne(d => d.IdCompte1Navigation).WithMany(p => p.PartieIdCompte1Navigations)
                .HasForeignKey(d => d.IdCompte1)
                .HasConstraintName("FK__Partie__id_compt__3B75D760");

            entity.HasOne(d => d.IdCompte2Navigation).WithMany(p => p.PartieIdCompte2Navigations)
                .HasForeignKey(d => d.IdCompte2)
                .HasConstraintName("FK__Partie__id_compt__3A81B327");
        });

        modelBuilder.Entity<Tour>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Tour__3213E83F7AA20671");

            entity.ToTable("Tour");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.IdPartie).HasColumnName("id_partie");
            entity.Property(e => e.NbrBatonnerRestants).HasColumnName("nbr_batonner_restants");
            entity.Property(e => e.NbrBatonnetRetirer).HasColumnName("nbr_batonnet_retirer");

            entity.HasOne(d => d.IdPartieNavigation).WithMany(p => p.Tours)
                .HasForeignKey(d => d.IdPartie)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Tour__id_partie__3E52440B");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
