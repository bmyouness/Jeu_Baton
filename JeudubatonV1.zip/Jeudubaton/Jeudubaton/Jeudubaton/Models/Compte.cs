﻿using System;
using System.Collections.Generic;

namespace Jeudubaton.Models;

public partial class Compte
{
    public int Id { get; set; }

    public string? Mail { get; set; }

    public string? Password { get; set; }

    public int? PartiePerdu { get; set; }

    public int? PartieGagné { get; set; }

    public virtual ICollection<Partie> PartieIdCompte1Navigations { get; set; } = new List<Partie>();

    public virtual ICollection<Partie> PartieIdCompte2Navigations { get; set; } = new List<Partie>();
}
