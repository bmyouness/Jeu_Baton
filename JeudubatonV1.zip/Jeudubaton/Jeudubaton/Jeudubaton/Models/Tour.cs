﻿using System;
using System.Collections.Generic;

namespace Jeudubaton.Models;

public partial class Tour
{
    public int Id { get; set; }

    public int NbrBatonnetRetirer { get; set; }

    public int NbrBatonnerRestants { get; set; }

    public int IdPartie { get; set; }

    public virtual Partie IdPartieNavigation { get; set; } = null!;
}
