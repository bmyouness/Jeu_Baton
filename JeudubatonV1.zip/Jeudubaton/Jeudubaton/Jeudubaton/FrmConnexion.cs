using Jeudubaton.Models;

namespace Jeudubaton
{
    public partial class FrmConnexion : Form
    {
        public static int IdCompteCourant
        {
            get;
            private set;
        }

        public FrmConnexion()
        {
            InitializeComponent();
        }

        private void TxtBoxIdentifiant_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnConnexion_Click(object sender, EventArgs e)
        {
            string emailRecherche = TxtBoxIdentifiant.Text;
            string motDePasse = TxtBoxMotdepasse.Text;
            using (FortBoyardYounessMaximePContext bdd = new FortBoyardYounessMaximePContext())
            {
                Compte? compte = bdd.Comptes.Where(o => o.Mail == emailRecherche && o.Password == motDePasse).SingleOrDefault();
                if (compte != null)
                {
                    // m�moriser l'id du compte 
                    IdCompteCourant = compte.Id;
                    FrmHeberge Hebergement = new FrmHeberge();
                    Hebergement.Show();
                }
                else
                {
                    MessageBox.Show("Email ou mot de passe incorrect !");
                }
            }
        }

        private void TxtBoxMotdepasse_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnRedirectionIdentifier_Click(object sender, EventArgs e)
        {
            FrmInscription new_inscription = new FrmInscription();
            new_inscription.Show();
        }
    }
}
